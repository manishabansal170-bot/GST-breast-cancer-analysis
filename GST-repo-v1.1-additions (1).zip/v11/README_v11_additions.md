# README additions for v1.1

Paste the table rows below into the "Running order" table in your existing
`README.md`, and add the two notes at the end of the "Notes on the analysis"
section. Then upload `scripts/11` through `scripts/15` to the repository.

---

## Rows to add to the running-order table

| Script | Produces |
|---|---|
| `11_pathway_network_coexpression.R` | Co-expression against an a priori functional panel, NRF2 target scoring, STRING network, GO/KEGG on family plus interaction partners |
| `12_drug_sensitivity.R` | Cell line drug IC50/AUC correlation (CCLE via cBioPortal) and neoadjuvant response (GSE25066) |
| `13_neoadjuvant_response_GSE25066.R` | GSE25066 from a locally downloaded series matrix; use if the GEO fetch in script 12 times out |
| `14_immune_infiltration.R` | Immune and stromal population scoring, purity-adjusted and within-subtype |
| `15_mirna_regulation.R` | miRNA–GST target pairs from multiMiR, tested against TCGA-BRCA miRNA expression |

Scripts 11–15 each require the cached expression from script 01. Script 15
additionally needs the miRNA matrix it fetches on first run. Script 13 needs
`GSE25066_series_matrix.txt.gz` in `cache/`.

---

## Notes to add to "Notes on the analysis"

- **Enrichment is computed on the family plus interaction partners, never on
  the family alone.** GO or KEGG enrichment of 16 GST genes returns
  "glutathione metabolism", which restates the input rather than finding
  anything. Co-expression is tested against a panel of functional processes
  chosen a priori from the literature, independently of the GST family.

- **Immune and miRNA correlations are adjusted for tumour purity and repeated
  within subtype.** Immune content and epithelial gene expression are both
  functions of sample composition; in this dataset 242 of 256 raw GST–immune
  associations (95%) did not survive purity adjustment. Basal-like tumours are
  additionally both GSTP1-high and immune-hot, so pooled correlations recover
  subtype rather than biology.

- **miRNA testing is restricted to predicted or validated target pairs.**
  Correlating all miRNAs against all GST genes tests roughly 30,000
  combinations and returns noise. Only pairs with prior database support are
  tested, and predicted pairs require support from at least two databases.
  Correlation indicates candidate regulation; demonstrating targeting requires
  experimental validation.

---

## Bug fixes included in v1.1

- **Script 14** previously stopped at the heatmap step, because `pheatmap`
  cannot cluster a matrix containing `NA`. The within-subtype analysis after it
  never ran, and the absent output file was easy to misread as a negative
  result. Heatmaps are now zero-filled for display only, with clustering
  disabled where a row or column has no variance; the underlying tables retain
  the `NA`s.

- **Script 14** consistency threshold relaxed from three subtypes to two.
  HER2-enriched has only 81 patients, so a genuine association can fail there
  on power alone; requiring three subtypes discarded the GSTM5–stromal
  association, which in fact holds in all four (rho 0.33–0.60, all FDR < 0.05).
  Per-subtype detail is now written out so the reader can judge directly.


- **Script 15** now converts miRNA accessions to names via `miRBaseConverter`.
  This is not cosmetic. multiMiR returns MIMAT identifiers, and converting them
  is what reveals whether the hits are scattered individual miRNAs or members
  of one polycistronic cluster. In this dataset the GSTM3 repressors resolve
  largely to miR-17~92 and its paralogues, which is the finding.

- **dplyr verbs are now namespace-qualified throughout scripts 11–15.**
  `AnnotationDbi`, `S4Vectors` and `multiMiR` each export their own `select()`,
  `filter()` and `rename()`. Once those packages attach, an unqualified dplyr
  call is dispatched to the wrong method and fails with an error that never
  mentions masking — "unable to find an inherited method for function 'select'"
  or "object 'highest' not found". Qualifying the calls removes a class of
  failure that is otherwise very hard to diagnose.

- **Script 15's heatmap block rewritten in base R** for the same reason.

---

## Release notes for v1.1

Suggested text for the GitHub release description:

> v1.1 — extended analysis
>
> Adds pathway and network analysis, drug sensitivity, neoadjuvant treatment
> response, immune infiltration and miRNA regulation modules.
>
> Fixes: a heatmap failure in the immune module that prevented the
> within-subtype analysis from running; an over-strict consistency threshold;
> namespace collisions between dplyr and Bioconductor packages that caused
> silent dispatch failures; and adds miRNA accession-to-name conversion.
