# Subtype-specific epigenetic regulation of the glutathione S-transferase family in breast cancer

Analysis code accompanying Gupta M, Kumar U, Singh S (2026).
*Subtype-specific promoter methylation specifies two divergent glutathione
S-transferase programmes in breast cancer.* [journal — update on acceptance]

---

## What this analyses

Twenty-two GST and GST-like genes across 5,833 breast tumours in three
independent cohorts, integrated with promoter methylation, somatic copy
number, mutation and proteomic data, with prognostic value tested against a
clinical baseline.

## Data sources

No raw data is redistributed here. The scripts download directly from the
sources below and cache locally. Processed summary tables are in `results/`.

| Dataset | n | Source |
|---|---|---|
| TCGA-BRCA + GTEx expression | 1,041 tumours + 292 normals | UCSC Xena Toil hub, dataset `TcgaTargetGtex_rsem_gene_tpm` |
| METABRIC expression + clinical | 1,608 | cBioPortal, study `brca_metabric` |
| SCAN-B expression + survival | 3,184 | GEO accession GSE96058 |
| HM450 methylation | 780 | cBioPortal, study `brca_tcga` |
| Copy number (GISTIC + linear) | 1,080 | cBioPortal, study `brca_tcga` |
| Somatic mutation | 982 | cBioPortal, study `brca_tcga` |
| Proteomics | 74 | cBioPortal, study `brca_tcga` |

The Toil recompute (Vivian et al., *Nat Biotechnol* 2017;35:314) is used for
TCGA and GTEx so that both are quantified through one identical pipeline.

## Running order

Set `WORKDIR` at the top of each script, then run in numerical order. Each
caches its downloads, so re-runs take seconds.

| Script | Produces |
|---|---|
| `01_expression_TCGA_GTEx.R` | Family expression across normal breast and PAM50 subtypes; Figure 1 |
| `02_expression_within_tumour.R` | Subtype comparison in tumours only, effect sizes; Figure 2A |
| `03_pergene_figures.R` | Per-gene publication figures with significance brackets |
| `04_validation_METABRIC.R` | METABRIC replication and concordance; Figure 2B |
| `05_validation_SCANB.R` | SCAN-B replication, FPKM→TPM conversion; Figure 2C |
| `06_methylation_expression.R` | Methylation–expression correlation; Figure 3 |
| `07_methylation_purity_subtype.R` | Purity-adjusted partial correlation, subtype methylation |
| `08_methylation_two_programme_test.R` | Two-programme test; Figures 4 and 5 |
| `09_copynumber_mutation_protein.R` | Copy number, mutation, variance partition, mRNA–protein |
| `10_survival.R` | Cox models, incremental C-index, LASSO score; Figure 6 |

Scripts 01–05 are independent of each other. Scripts 06–08 run in sequence.
Script 09 requires the methylation cache from 06. Script 10 is independent.

## Notes on the analysis

Several decisions in the code are deliberate and worth flagging for anyone
reusing it:

- **Ensembl version suffixes are stripped before mapping.** Without this,
  genes such as GSTM2 and GSTM4 return spuriously zero values in GDC and Toil
  annotations.
- **Detection is assessed per sample group, not on a pooled median.** A gene
  silenced in tumour but expressed in normal tissue is otherwise
  misclassified as undetected.
- **Methylation–expression correlations use primary tumours only.** Including
  normals generates correlation from the tumour/normal difference in both
  variables rather than from regulation.
- **Correlations are adjusted for tumour purity** (Aran et al., *Nat Commun*
  2015) via rank residuals, because GST genes are epithelial and bulk
  measurements are composition-sensitive.
- **cBioPortal returns discrete data sparsely.** GISTIC calls and mutations
  are transmitted only for altered samples, so frequencies must be computed
  against the sample-list denominator, not the number of rows returned.
  Correlations use the continuous linear copy-number profile.
- **Survival inference uses continuous Cox models**, not median splits.
  Kaplan–Meier curves are illustrative only. LASSO coefficients are locked on
  TCGA before application to METABRIC.
- **GSTM1 and GSTT1 carry common germline deletions** and are excluded from
  regulatory conclusions. GSTT1 is additionally absent from the GRCh38
  primary assembly (alternate scaffold NT_187633.1 only).

## Environment

R 4.6.1.

Bioconductor: `TCGAbiolinks`, `SummarizedExperiment`, `cBioPortalData`,
`GEOquery`
CRAN: `UCSCXenaTools`, `dplyr`, `tidyr`, `tibble`, `ggplot2`, `ggpubr`,
`pheatmap`, `RColorBrewer`, `data.table`, `R.utils`, `survival`, `survminer`,
`glmnet`, `timeROC`, `curl`

Full `sessionInfo()` for each module is written to `provenance_*.txt`
alongside the outputs.

## Results included

`results/` contains the processed tables underlying the figures and tables in
the paper. Raw cohort data is not redistributed; see Data sources above.

## Licence

MIT — see `LICENSE`.

## Citation

[Add paper citation on acceptance]

Code archived at Zenodo: [DOI]
