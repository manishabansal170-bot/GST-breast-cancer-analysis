# Results

Processed tables underlying the figures and tables in the paper.

Copy your output CSVs here before publishing the repository. The files
referenced in the manuscript are:

- detection_bygroup_toil.csv          gene inclusion, per-group TPM (Table 1)
- stats_toil.csv                      expression, effect sizes (Table 2)
- subtype_medians_wide_toil.csv       median TPM by subtype
- subtype_stats_toil.csv              Kruskal-Wallis, epsilon-squared
- tcga_metabric_concordance.csv       cross-cohort replication (Table 3)
- three_cohort_concordance.csv        three-cohort replication
- metabric_subtype_medians.csv        METABRIC by subtype
- scanb_subtype_medians.csv           SCAN-B by subtype
- methylation_expression_correlation.csv
- methylation_expression_purity_adjusted.csv
- methylation_pattern.csv             bimodality classification
- methylation_by_subtype.csv
- GSTP1_methylation_by_subtype.csv
- cna_vs_methylation_variance.csv     variance partition (Table 4)
- copy_number_frequency.csv
- mutation_frequency.csv
- mrna_protein_concordance.csv
- univariate_cox_metabric.csv         survival (Table 5)
- incremental_cindex_metabric.csv
- risk_score_model.csv
- provenance_*.txt                    sessionInfo per module

Raw cohort data is not redistributed. See the main README for sources.
